CHIMEFRB -- FRB L1 Operations Web Application 
=============================================

This is a web application to operate the FRB backend of CHIMEFRB.
~                                                        
